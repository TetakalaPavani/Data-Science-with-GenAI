from flask import Flask, request

app = Flask(__name__)

# Home route
@app.route("/")
def home():
    name = request.args.get("name", "Guest")  # default name
    upper_name = name.upper()

    return f"""
    <html>
        <head>
            <title>Flask Fun App</title>
            <style>
                body {{
                    background-color: #f0f8ff;
                    font-family: Arial;
                    text-align: center;
                    margin-top: 100px;
                }}
                h1 {{
                    color: #2c3e50;
                }}
            </style>
        </head>
        <body>
            <h1>HELLO {upper_name} 👋</h1>
            <p>Welcome to the Flask Application</p>
            <p>Try other routes too 😄</p>
        </body>
    </html>
    """
if __name__ == "__main__":
    app.run()



