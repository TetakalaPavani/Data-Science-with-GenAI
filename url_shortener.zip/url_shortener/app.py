from flask import Flask, render_template, request, redirect, url_for, flash
from models import db, URL, User
import string, random
import validators

from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from flask_bcrypt import Bcrypt

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret123'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///urls.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

bcrypt = Bcrypt(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Create DB
with app.app_context():
    db.create_all()

# Generate short code
def generate_code(length=6):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

# 🔷 HOME
@app.route('/')
def home():
    return render_template('home.html')

# 🔷 SIGNUP
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if len(username) < 5 or len(username) > 9:
            flash("Username must be between 5 to 9 characters")
            return redirect('/signup')

        if User.query.filter_by(username=username).first():
            flash("Username already exists")
            return redirect('/signup')

        hashed = bcrypt.generate_password_hash(password).decode('utf-8')

        user = User(username=username, password=hashed)
        db.session.add(user)
        db.session.commit()

        flash("Signup successful! Please login.")
        return redirect('/login')

    return render_template('signup.html')

# 🔷 LOGIN
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()

        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            return redirect('/dashboard')
        else:
            flash("Invalid credentials")
            return redirect('/login')

    return render_template('login.html')

# 🔷 LOGOUT
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/login')

# 🔷 DASHBOARD
@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    short_url = None

    if request.method == 'POST':
        original_url = request.form.get('url')

        if not validators.url(original_url):
            flash("Invalid URL")
            return redirect('/dashboard')

        code = generate_code()

        new_url = URL(original_url=original_url, short_code=code)
        db.session.add(new_url)
        db.session.commit()

        short_url = request.host_url + code

    urls = URL.query.all()
    return render_template('dashboard.html', short_url=short_url, urls=urls)

# 🔷 REDIRECT
@app.route('/<code>')
def redirect_url(code):
    url = URL.query.filter_by(short_code=code).first()
    if url:
        return redirect(url.original_url)
    return "URL not found"

if __name__ == '__main__':
    app.run(debug=True)