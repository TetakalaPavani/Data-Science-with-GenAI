# AI-Based Prediction System

## Description
This project trains a machine learning model and performs inference.

## How to Run
1. Install dependencies:
   pip install -r requirements.txt

2. Train model:
   python src/train.py

3. Run inference:
   python src/inference.py
