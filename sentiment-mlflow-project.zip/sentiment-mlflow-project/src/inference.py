import pickle

# Load model
model = pickle.load(open("model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

# New review
text = ["this product is very good"]
text_vec = vectorizer.transform(text)

prediction = model.predict(text_vec)

print("Sentiment:", "Positive" if prediction[0]==1 else "Negative")
